Continuous integration & deployment of builds in github with tools like Jenkins & TeamCity
